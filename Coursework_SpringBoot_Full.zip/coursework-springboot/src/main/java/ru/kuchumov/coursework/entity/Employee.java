package ru.kuchumov.coursework.entity;

import lombok.*;
import javax.persistence.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity @Table(name = "employees")
public class Employee {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String surname;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Integer age;

    @Column(nullable = false)
    private String department;

    @Column(nullable = false)
    private Double salary;

    @Column(name = "created_by", nullable = false)
    private String createdBy;
}
