package ru.kuchumov.coursework.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import ru.kuchumov.coursework.entity.UserAction;
import ru.kuchumov.coursework.repository.UserActionRepository;
import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class ActionLogService {

    private final UserActionRepository userActionRepository;

    public ActionLogService(UserActionRepository userActionRepository) {
        this.userActionRepository = userActionRepository;
    }

    public void logAction(String username, String description) {
        String actor = (username == null || username.isBlank()) ? "ANONYMOUS" : username;
        UserAction action = new UserAction(null, LocalDateTime.now(), actor, description);
        userActionRepository.save(action);
        // Одновременная запись в файл логов logs/application.log
        log.info("USER_ACTION [user={}]: {}", actor, description);
    }

    public List<UserAction> getAllActions() {
        return userActionRepository.findAllByOrderByDateActionsDesc();
    }
}
