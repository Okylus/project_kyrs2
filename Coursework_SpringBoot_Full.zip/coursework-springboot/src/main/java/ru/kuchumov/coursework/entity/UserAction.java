package ru.kuchumov.coursework.entity;

import lombok.*;
import javax.persistence.*;
import java.time.LocalDateTime;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity @Table(name = "user_actions")
public class UserAction {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "date_actions", nullable = false)
    private LocalDateTime dateActions;

    @Column(name = "username", nullable = false)
    private String username;

    @Column(name = "description", nullable = false, length = 500)
    private String description;
}
