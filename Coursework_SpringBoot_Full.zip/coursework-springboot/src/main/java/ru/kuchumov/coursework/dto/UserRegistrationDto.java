package ru.kuchumov.coursework.dto;

import lombok.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Data @NoArgsConstructor @AllArgsConstructor
public class UserRegistrationDto {
    @NotBlank(message = "Логин не может быть пустым")
    @Size(min = 3, max = 50)
    private String username;

    @NotBlank(message = "Укажите ФИО пользователя")
    private String fullName;

    @NotBlank(message = "Пароль не может быть пустым")
    @Size(min = 4)
    private String password;
}
