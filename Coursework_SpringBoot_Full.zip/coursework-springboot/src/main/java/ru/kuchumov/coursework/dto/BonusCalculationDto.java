package ru.kuchumov.coursework.dto;

import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class BonusCalculationDto {
    private Long employeeId;
    private String employeeName;
    private Double monthlySalary = 85000.0;
    private Integer experienceYears = 3;
    private Double kpiPercent = 100.0;

    private Double baseBonus;
    private Double experienceBonus;
    private Double totalBonusGross;
    private Double taxNdfl;
    private Double totalBonusNet;
    private Double annualIncomeNet;
}
