package ru.kuchumov.coursework.entity;

import lombok.*;
import javax.persistence.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor
@Entity @Table(name = "addresses")
public class Address {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String city;

    @Column(nullable = false)
    private String street;

    @Column(nullable = false)
    private String building;

    @Column(name = "postal_code")
    private String postalCode;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "employee_id")
    private Employee employee;

    @Column(name = "created_by", nullable = false)
    private String createdBy;
}
