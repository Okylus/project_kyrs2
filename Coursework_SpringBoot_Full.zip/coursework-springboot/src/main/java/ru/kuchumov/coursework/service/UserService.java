package ru.kuchumov.coursework.service;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import ru.kuchumov.coursework.dto.UserRegistrationDto;
import ru.kuchumov.coursework.entity.Role;
import ru.kuchumov.coursework.entity.User;
import ru.kuchumov.coursework.repository.RoleRepository;
import ru.kuchumov.coursework.repository.UserRepository;
import java.util.Collections;
import java.util.List;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final RoleRepository roleRepository;
    private final PasswordEncoder passwordEncoder;
    private final ActionLogService actionLogService;

    public UserService(UserRepository userRepository, RoleRepository roleRepository,
                       PasswordEncoder passwordEncoder, ActionLogService actionLogService) {
        this.userRepository = userRepository;
        this.roleRepository = roleRepository;
        this.passwordEncoder = passwordEncoder;
        this.actionLogService = actionLogService;
    }

    public void registerNewUser(UserRegistrationDto dto) {
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setFullName(dto.getFullName());
        user.setPassword(passwordEncoder.encode(dto.getPassword()));

        Role readOnlyRole = roleRepository.findByName("ROLE_READ_ONLY");
        if (readOnlyRole == null) {
            readOnlyRole = roleRepository.save(new Role("ROLE_READ_ONLY"));
        }
        user.setRoles(Collections.singletonList(readOnlyRole));
        userRepository.save(user);
        actionLogService.logAction(dto.getUsername(), "Зарегистрирован новый пользователь с ролью по умолчанию ROLE_READ_ONLY");
    }

    public void updateUserRole(Long userId, String roleName, String adminUsername) {
        User user = userRepository.findById(userId).orElse(null);
        Role role = roleRepository.findByName(roleName);
        if (user != null && role != null) {
            user.getRoles().clear();
            user.getRoles().add(role);
            userRepository.save(user);
            actionLogService.logAction(adminUsername, "Администратор изменил роль пользователя '" + user.getUsername() + "' на " + roleName);
        }
    }

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    public List<User> findAllUsers() {
        return userRepository.findAll();
    }
}
