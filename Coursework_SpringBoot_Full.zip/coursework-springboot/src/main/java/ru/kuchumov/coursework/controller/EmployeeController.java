package ru.kuchumov.coursework.controller;

import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.kuchumov.coursework.entity.Employee;
import ru.kuchumov.coursework.repository.EmployeeRepository;
import ru.kuchumov.coursework.service.ActionLogService;
import java.util.List;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;
    private final ActionLogService actionLogService;

    public EmployeeController(EmployeeRepository employeeRepository, ActionLogService actionLogService) {
        this.employeeRepository = employeeRepository;
        this.actionLogService = actionLogService;
    }

    @GetMapping
    public String listEmployees(Model model, Authentication auth) {
        String username = auth.getName();
        boolean isAdmin = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));
        boolean isReadOnly = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_READ_ONLY"));

        // Роль USER видит только свои записи, ADMIN и READ_ONLY видят все записи
        List<Employee> employees = (isAdmin || isReadOnly)
                ? employeeRepository.findAll()
                : employeeRepository.findByCreatedBy(username);

        actionLogService.logAction(username, "Просмотр таблицы сотрудников (записей: " + employees.size() + ")");
        model.addAttribute("employees", employees);
        model.addAttribute("canEdit", !isReadOnly);
        return "list-employees";
    }
}
